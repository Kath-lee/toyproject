<div id="bot_copy">
  <p><strong>&copy;2015. Team.Uranus</strong> 곽현우 | 안윤진 | 이고은 | 최성훈<br/>Portfolio page<br/>페이지 내 일부 이미지는 비상업적인 용도로 사용하였습니다. 해당 이미지는 원본 저작권자에게 권리가 있음을 밝힙니다.</p>
</div>