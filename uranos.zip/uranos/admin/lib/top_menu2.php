<div class="home_logo"><a href="../../index.php"><img src="../img/logo.png" alt="Uranus Festival 회원 페이지로" title="Uranus Festival 회원 페이지로"></a></div>
<ul class="top_menu">
<li><a class="a_menu1" href="../ticket/myticket_ad.php">FESTIVAL</a></li>
<li><a class="a_menu2" href="../login/memberlist_admin.php">MEMBER</a></li>
<li><a class="a_menu3" href="../board_notice/list.php">BOARD</a></li>
</ul> 